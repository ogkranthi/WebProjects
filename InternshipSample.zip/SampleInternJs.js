/**
 * Created by kranthikumar on 2/23/17.
 */
document.body.onload = firstDropDown('listID0',-1);

function firstDropDown(dropSelected,listid) {

    listid = listid + 1;
    var ele = document.createElement('div');

    var select = document.createElement('select');
    var currentID = select.id = "listID" + (listid);
    var currentSelected = dropSelected;
    console.log(ele);
    var states = jsonstr[currentSelected];
    var stopt = document.createElement('option');
    var flag = 0;
    stopt.value = stopt.text = "select";
    select.appendChild(stopt);
    states.forEach(function (element){
        console.log(element);
        stopt = document.createElement('option');
        stopt.value = stopt.text = element;
        select.appendChild(stopt);
    });


    if (listid > 3 || flag == 1){
        console.log("this is final" + listid + flag);
    } else {
        ele.appendChild(select);
        document.getElementsByTagName('body')[0].appendChild(ele);
        document.getElementById(currentID).addEventListener("change", function () {
            console.log("selected inside event" + currentID);
            var deleteID = 4;
            while (deleteID > listid) {
                var present = document.getElementById("listID" + (deleteID));
                console.log(present);
                if (present != null) {
                    console.log("inside already present");
                    present.parentNode.removeChild(present);
                }

                deleteID = deleteID - 1;
            }
            myfunction(listid);
        });
    }
}
