————API Used————

1)about
2)degrees
3)minors
4)employment (including both Coop and Employment Tables)
#People (Only faculty, but not the Staff)
5)Research
#ContactForm
#Maps
#Some parts of News and Footer

———Methods invoked——

“myReq”: It is the method, that is used repeatedly with different parameters for the API.
forEach is used to iterate every sub-element, if there are any repeated elements. 

———Plugins used———

1)Menu Plugin/ Navbar: 
The Menu bar on top of the page that shows the menu when clicked and redirects to the corresponding links.
2)Bounce: Used with degree details button, when clicked creates a bounce effect and shows the degree options. Another plugin (Lightbox/Remodal) on top of this plugin is embedded to manage data effectively.
3)dataTables: Used with Co-op and employment tables.
4)FeatherLight/Remodal: This effect pops the hidden data out, when clicked. It is used with degrees and research.

Note: All the required resources like styling and images for the corresponding plugins are included.

——How to use the site——

1) RIT Logo, when clicked redirects to RIT Main Page.
2) LOGIN redirects to myRit page, which has different login links available.
3) MYCourses redirects to Mycourses login page.
4) Menu, when clicked result in different options and social links related to RIT and IST in particular. The “cross” on the top right corner must be clicked to exit from the Menu.
5) “Click for degree” details button shows up degree details with short forms and when clicked again on each element pops the degree information. “OK!” or anywhere else outside the div element can be clicked to exit from the dialog box
6) Minor information with title, description and subjects can be obtained when clicked on the corresponding minor element in the “Our undergraduate minors” section.
7) Co-op Details and Employment details are set in a table formats and any operation like sorting according to city, term etc can be done or the view results can be alternated using the attributes section in the tables.
8) Research areas has area element to be clicked to pop up the dialog box about the citation information about the corresponding research area.
9) Footer has links to the required resource pages for maps and ask us details.


——Why you went above and beyond "B" work?——
For the Complete nature of the Website and an attempt for the Website to look a bit professional

———Link to hosted application———
https://people.rit.edu/kxm2263/ISTWebsite/