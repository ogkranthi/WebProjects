
    //General function to be used in different calls to obtain data from different API elements
    function myReq(typ, dat) {
        return $.ajax({
            type: typ,
            url: 'https://people.rit.edu/~sarics/web_proxy.php?path=',
            dataType: 'json',
            data: dat,
            cache: false,
            async: true,
        }).fail(function () {
            console.log("There was a problem while trying to get data");
        });
    }

    $(document).ready(function ()
    {
        //Data retrieval from About
        myReq('get',{path:'/about/'}).done(function (json) {
        var titleHtml = document.createTextNode(json.title);
        titleHtml.id = 'aboutHeader';
        $('#abouttitle').append(titleHtml);
        var decriptionHtml = document.createTextNode(json.description);
        $('#aboutp').append(decriptionHtml);
        var quoteHtml = document.createTextNode(json.quote);
        $('#quote').append(quoteHtml);
        var quoteAuthor = document.createTextNode(json.quoteAuthor);
        $('#author').append(quoteAuthor);

        });

        //Data retrieval from Degrees
        myReq('get',{path:'/degrees/'}).done(function (json) {
            $.each(json.undergraduate,function (i,element) {


                switch (element.degreeName) {
					case 'cit':
                        var CITHtml = document.createTextNode(element.title);
                        $('#CITTitle').append(CITHtml);
                        var CITdesc = document.createTextNode(element.description);
                        $('#CITDesc').append(CITdesc);
                        $.each(element.concentrations, function (j, concentration) {
                            $('#CITlist').append("<li>"+concentration+"</li>");
                        });
                        break;

                    case 'wmc':
                        var WMCHtml = document.createTextNode(element.title);
                        $('#WMCTitle').append(WMCHtml);
                        var WMCdesc = document.createTextNode(element.description);
                        $('#WMCDesc').append(WMCdesc);
                        $.each(element.concentrations, function (j, concentration) {
                            $('#WMClist').append("<li>"+concentration+"</li>");
                        });
                        break;

                    case 'hcc':
                        var HCCHtml = document.createTextNode(element.title);
                        $('#HCCTitle').append(HCCHtml);
                        var HCCDesc = document.createTextNode(element.description);
                        $('#HCCDesc').append(HCCDesc);
                        $.each(element.concentrations, function (j, concentration) {
                            $('#HCClist').append("<li>"+concentration+"</li>");
                        });
                        break;

					default:
					    console.log("default is selected");
                }

            });

           		 $.each(json.graduate,function (i,element) {

                     switch (element.degreeName) {
                         case 'hci':
                             var HCIHtml = document.createTextNode(element.title);
                             $('#HCITitle').append(HCIHtml);
                             var HCIdesc = document.createTextNode(element.description);
                             $('#HCIDesc').append(HCIdesc);
                             $.each(element.concentrations, function (j, concentration) {
                                 $('#HCIlist').append("<li>"+concentration+"</li>");
                             });
                             break;

                         case 'ist':
                             var ISTHtml = document.createTextNode(element.title);
                             $('#ISTTitle').append(ISTHtml);
                             var ISTdesc = document.createTextNode(element.description);
                             $('#ISTDesc').append(ISTdesc);
                             $.each(element.concentrations, function (j, concentration) {
                                 $('#ISTlist').append("<li>"+concentration+"</li>");
                             });
                             break;

                         case 'nsa':
                             var NSAHtml = document.createTextNode(element.title);
                             $('#NSATitle').append(NSAHtml);
                             var NSADesc = document.createTextNode(element.description);
                             $('#NSADesc').append(NSADesc);
                             $.each(element.concentrations, function (j, concentration) {
                                 $('#NSAlist').append("<li>"+concentration+"</li>");
                             });
                             break;

                         default:
                             $.each(element.availableCertificates, function (j, certificate) {
                                 $('#advlist').append("<li>"+certificate+"</li>");
                             });
                     }
				 });
  
        });

        //Minor data retrieval
        myReq('get',{path:'/minors/'}).done(function (json) {
            $.each(json,function (i,element) {
                var nameP = document.createElement("p");
                var nameHtml = document.createTextNode(element.name);
                nameP.append(nameHtml);
                nameP.className = "nameClass";
                var titleP = document.createElement("p");
                var titleHtml = document.createTextNode(element.title);
                titleP.append(titleHtml)
                titleP.className = "titleClass";
                var descP = document.createElement("p");
                var descHtml = document.createTextNode(element.description);
                descP.append(descHtml);
                descP.className = "descClass";
                var node = document.createElement("UL");
                node.className = "lightList";
                $('.light')[i].append(nameP);
                $('.light')[i].append(titleP);
                $('.light')[i].append(descP);
                $('.light')[i].append(node);
                $.each(element.courses,function (j,course) {
                    var courseHtml = document.createTextNode(course);
                     $('.lightList')[i].append(course+"  ");
                });
            });
		});


        //Employment details with Coop and employmentTables
         myReq('get',{path:'/employment/'}).done(function (json) {
             
             var empMainTitleHtml = document.createTextNode(json.introduction.title);
             $('#empMainTitle').append(empMainTitleHtml);
             $.each(json.introduction.content,function(i,element){
                 console.log("inside class");
                 var contentTitle = '<p class="emptitle">'+element.title+'</p';
                 var contentDesc  = '<p class="empdesc">'+element.description+'</p>';
                 $('#content').append(contentTitle);
                 $('#content').append(contentDesc);
             });

             $.each(json.degreeStatistics.statistics,function (i,element) {
                 $('#stat').append('<li>'+element.value+'  '+element.description+'</li>');
             });

             $.each(json.employers.employerNames,function (i,element) {
                 $('#empNames').append('<li>'+element+'</li>');
             });

             $.each(json.careers.careerNames,function (i,element) {
                 $('#carNames').append('<li>'+element+'</li>');
             });

            var tableData;
             $.each(json.coopTable.coopInformation,function (i,element) {
                tableData += '<tr><td>'+element.employer+'</td>' ;
                tableData += '<td>'+element.degree+'</td>';
                tableData += '<td>'+element.city+'</td>';
                tableData += '<td>'+element.term+'</td></tr>';
            });
             $('#coopTableBody').append(tableData);
              $('#coopTable').DataTable({
                "pagingType": "full_numbers",
                "paging": true
            });//for coop table
             var empData;
             $.each(json.employmentTable.professionalEmploymentInformation,function (i,element) {
                 empData += '<tr><td>'+element.employer+'</td>' ;
                 empData += '<td>'+element.degree+'</td>';
                 empData += '<td>'+element.city+'</td>';
                 empData += '<td>'+element.title+'</td>';
                 empData += '<td>'+element.startDate+'</td></tr>';
             });
             $('#empTableBody').append(empData);
             $('#empTable').DataTable({
                 "pagingType": "full_numbers",
                 "paging": true
             });//for employment table
		});

        //People div data retrieval
        myReq('get',{path:'/people/'}).done(function (json){
            var imgData="";
            $.each(json.faculty,function (i,element){
                imgData += "<div class='profDetails'><img src='" + element.imagePath + "'" + "class=\'prof\'" + "/>"+
                    "<p>"+element.name+"<br/>"+element.title+"<br/>"+element.email+"<br/>"+"</p>"+"</div>";

            });
            $('#fac').append(imgData);

        });

        //Research div data retrieval
        myReq('get',{path:'/research/'}).done(function (json) {
            var citHtml;
            $.each(json.byInterestArea,function(i,element){

                var titleP = document.createElement("p");
                titleHtml = document.createTextNode("Citations");
                titleP.append(titleHtml);
                titleP.className = "citationTitle";
                $('.ligh')[i].append(titleP);

                $.each(element.citations,function (j,elem) {
                    var citP = document.createElement("p");
                    citHtml = document.createTextNode(elem);
                    citP.append(citHtml);
                    citP.className = "citation";
                    $('.ligh')[i].append(citP);
                });

            });

        });


        //Remodal Plugin calls- Lightbox
        	$('[data-remodal-id=CITmodal]').remodal({
                modifier: 'with-red-theme'
        	});

            $('[data-remodal-id=HCCmodal]').remodal({
                modifier: 'with-red-theme'
            });

            $('[data-remodal-id=WMCmodal]').remodal({
                modifier: 'with-red-theme'
            });

            $('[data-remodal-id=ISTmodal]').remodal({
                modifier: 'with-red-theme'
            });

            $('[data-remodal-id=HCImodal]').remodal({
                modifier: 'with-red-theme'
            });

            $('[data-remodal-id=NSAmodal]').remodal({
                modifier: 'with-red-theme'
            });
    });
