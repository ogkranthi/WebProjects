Features:

DHTML is used to slide the title of the HTMl page.

“RESET” button allows the user to start over again from the first choice (which is state),
and reset all the subsequent values.

The select dropdowns are created dynamically, depending on the previous user selection and the corresponding data fetched from the jsonp file.

“YOUR SELECTION” button appears when all selections are made and allows the user to view all the selections, when clicked.

“Apply” button creates a form dynamically and allows the user to enter their information.

The form data is validated to check if all the values are entered and the basic format of the email is checked.

Local storage is used to save the user information and welcome him when he tries to refill the form. Initially, a general guest greeting message is displayed to the user. (For new users, local storage has to be cleared).


